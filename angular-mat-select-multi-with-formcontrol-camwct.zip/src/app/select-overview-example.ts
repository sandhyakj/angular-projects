import { Component } from '@angular/core';
import { OnInit } from '@angular/core/src/metadata';
import { FormControl } from '@angular/forms';
export interface Food {
  group: string;
  value: string;
  viewValue: string;
}

/**
 * @title Mat-Select Multiple initialisation with ngModel
 */
@Component({
  selector: 'select-overview-example',
  templateUrl: 'select-overview-example.html',
  styleUrls: ['select-overview-example.css'],
})
export class SelectOverviewExample implements OnInit {
  groupMap = new Map();

  allfoods = ['*', 1, 2];
  myselectedFoods = [];
  selectedgroup: any = null;
  foodForm: FormControl = new FormControl(this.myselectedFoods);

  ngOnInit() {
    this.allfoods.forEach((value) => {
      if (value == '*') {
        this.groupMap.set(value, 'g1');
      } else {
        this.groupMap.set(value, 'g2');
      }
    });
  }

  change(state, value) {
    console.log(state + '  ' + value);
    if (state) {
      if (value == '*') {
        this.selectedgroup = 'g1';
      } else {
        this.selectedgroup = 'g2';
      }
    } else {
      if (value == '*') {
        this.selectedgroup = null;
      } else {
        let foodformlength = this.foodForm.value.filter((item) => item !== '*');
        if (foodformlength > 0) {
          this.selectedgroup = 'g2';
        } else {
          foodformlength = this.foodForm.value.filter((item) => item == '*');
          if (foodformlength > 0) {
            this.selectedgroup = 'g1';
          } else {
            this.selectedgroup = null;
          }
        }
      }
    }
  }
}
