import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
/**
 * @title Mat-Select Multiple initialisation with ngModel
 */
@Component({
  selector: 'app-select-overview-example',
  templateUrl: './select-overview-example.component.html',
  styleUrls: ['./select-overview-example.component.css'],
})
export class SelectOverviewExampleComponent implements OnInit {
  groupMap = new Map();
  @Input() allfoods: Array<string | number> = [];
  @Output() selected = new EventEmitter<Array<string | number>>();

  myselectedFoods = [];
  selectedgroup: string = null;
  foodForm: Array<string | number> = [];

  ngOnInit() {
    this.allfoods.forEach((value) => {
      if (value == '*') {
        this.groupMap.set(value, 'g1');
      } else {
        this.groupMap.set(value, 'g2');
      }
    });
  }

  setSelected() {
    // console.log(this.foodForm);
    this.selected.emit(this.foodForm);
  }

  change(state, value) {
    this.setSelected();
    if (state) {
      if (value == '*') {
        this.selectedgroup = 'g1';
      } else {
        this.selectedgroup = 'g2';
      }
    } else {
      if (value == '*') {
        this.selectedgroup = null;
      } else {
        let foodformlength = this.foodForm.filter(
          (item) => item !== '*'
        ).length;
        if (foodformlength > 0) {
          this.selectedgroup = 'g2';
        } else {
          foodformlength = this.foodForm.filter((item) => item == '*').length;
          if (foodformlength > 0) {
            this.selectedgroup = 'g1';
          } else {
            this.selectedgroup = null;
          }
        }
      }
    }
  }
}
