import { Component } from '@angular/core';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
  selected: string | number;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    symbol: 'H',
    selected: null,
  },
  { position: 2, name: 'Helium', weight: 4.0026, symbol: 'He', selected: null },
  { position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li', selected: null },
  {
    position: 4,
    name: 'Beryllium',
    weight: 9.0122,
    symbol: 'Be',
    selected: null,
  },
  { position: 5, name: 'Boron', weight: 10.811, symbol: 'B', selected: null },
];

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'table-basic-example',
  styleUrls: ['table-basic-example.css'],
  templateUrl: 'table-basic-example.html',
})
export class TableBasicExample {
  displayedColumns: string[] = [
    'position',
    'name',
    'weight',
    'symbol',
    'selected',
  ];
  dataSource = ELEMENT_DATA;
  allfoods: Array<string | number> = ['*', 1, 2];

  setSelected(value, element) {
    element.selected = value;
    console.log(element);
  }
}

/**  Copyright 2021 Google LLC. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */
